GoalOS / AGIALPHA Autopilot Command Center v2

Start here:
1. pdfs/00_OPEN_FIRST_AGIALPHA_Autopilot_Command_Center_v2.pdf
2. pdfs/GoalOS_AGIALPHA_Autopilot_All_in_One_Book_v2.pdf
3. editable_docs/02_Codex_Implementation_Prompt_AGIALPHA_Autopilot_v2.docx
4. technical_assets/AGIALPHA_Autopilot_Code_Kit_v2.zip
5. spreadsheets/06_AGIALPHA_Autopilot_Economics_Thermostat_Model_v2.xlsx

Core rule:
Use $AGIALPHA only where proof changes state.

Claim boundary:
No ROI/yield/token-price claims. No AGI/ASI achievement claim. No Mainnet deployment claim. No production safety or external audit claim.
