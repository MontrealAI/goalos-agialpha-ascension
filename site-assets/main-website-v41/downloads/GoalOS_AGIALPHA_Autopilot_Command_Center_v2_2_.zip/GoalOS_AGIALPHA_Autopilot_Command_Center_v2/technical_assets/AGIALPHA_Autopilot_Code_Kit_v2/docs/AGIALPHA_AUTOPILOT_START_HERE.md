# AGIALPHA Autopilot - Start Here

AGIALPHA Autopilot turns a mission into a budget quote, ProofBundle, Evidence Docket, reviewer packet, alpha-WU score, settlement-readiness report, treasury route, and Chronicle entry.

## First command

```bash
python scripts/agialpha-autopilot/agialpha_autopilot.py \
  --mission examples/agialpha-missions/proof-card-010a-cyber-evidence-docket.json \
  --policy config/agialpha-autopilot.policy.json \
  --out evidence/agialpha-autopilot/proof-card-010a \
  --mode simulation
```

## Rule

Use AGIALPHA only where proof changes state. No ProofBundle, no settlement. No eval, no propagation. No rollback, no release.
