# Mainnet Read-Only

Mainnet workflow is read-only. No private key. No broadcast. No Mainnet value movement.
