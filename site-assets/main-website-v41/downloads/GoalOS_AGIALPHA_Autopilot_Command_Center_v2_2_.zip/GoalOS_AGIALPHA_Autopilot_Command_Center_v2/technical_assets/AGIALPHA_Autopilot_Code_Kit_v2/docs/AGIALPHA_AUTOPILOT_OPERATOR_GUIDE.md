# Operator Guide

1. Run simulation.
2. Review generated Evidence Docket.
3. Send reviewer packet.
4. Do not settle until settlement-readiness is ready and human review is complete.
