# Sepolia Rehearsal

Use only testnet funds and protected GitHub environments. Sepolia rehearsal is not production readiness.
