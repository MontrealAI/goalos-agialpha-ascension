#!/usr/bin/env python3
import argparse, json, os, hashlib, datetime, pathlib, html

CLAIM_BOUNDARY = "This evidence reports proof-settlement readiness only. It does not claim achieved AGI, ASI, superintelligence, guaranteed ROI, yield, legal approval, tax approval, security approval, external audit completion, production safety, token price appreciation, or Ethereum Mainnet deployment."

def load_json(path):
    with open(path, 'r', encoding='utf-8') as f: return json.load(f)

def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(data, (dict, list)):
        path.write_text(json.dumps(data, indent=2), encoding='utf-8')
    else:
        path.write_text(data, encoding='utf-8')

def sha256_text(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()

def must_not_mainnet_broadcast(mode):
    if os.environ.get('GITHUB_ACTIONS','').lower() == 'true' and mode in {'mainnet','mainnet_human_gated'}:
        raise SystemExit('Refusing: GitHub Actions must not broadcast Ethereum Mainnet transactions.')

def compute(mission, policy, mode):
    must_not_mainnet_broadcast(mode)
    risk = mission.get('risk_tier','low')
    tier = policy['riskTiers'][risk]
    agi = mission['agialpha']
    total = float(agi.get('escrow_budget',0)) + float(agi.get('reviewer_budget',0)) + float(agi.get('treasury_allocation',0))
    cap_ok = total <= float(tier['maxJobBudgetAGIALPHA'])
    split = policy['settlementSplit']
    proof = mission.get('proof_requirements',{})
    proof_complete = all(bool(v) for v in proof.values())
    base_quality = 0.78 if proof_complete else 0.0
    risk_mult = {'low':1.0,'medium':1.35,'high':1.8}[risk]
    difficulty = {'low':1.0,'medium':1.4,'high':2.0}[risk]
    slo = 0.95 if cap_ok else 0.4
    confidence = 0.72 if proof_complete else 0.1
    policy_pass = 1.0 if cap_ok and proof_complete else 0.0
    alpha_wu = round(100 * difficulty * base_quality * slo * confidence * policy_pass, 4)
    release_conditions = mission.get('settlement',{}).get('release_conditions',[])
    missing = []
    if not cap_ok: missing.append('budget_exceeds_risk_tier_cap')
    if not proof.get('proof_bundle'): missing.append('proof_bundle_missing')
    if not proof.get('evidence_docket'): missing.append('evidence_docket_missing')
    if not proof.get('reviewer_attestation'): missing.append('reviewer_attestation_missing')
    if not proof.get('rollback_plan'): missing.append('rollback_plan_missing')
    status = 'READY_FOR_SIMULATED_REVIEW' if not missing else 'BLOCKED'
    if mode == 'mainnet_readonly': status = 'MAINNET_READONLY_OPERATOR_PACKET_ONLY'
    quote = {'mission_id':mission['mission_id'],'mode':mode,'risk_tier':risk,'total_budget_agialpha':total,'risk_tier_cap':tier['maxJobBudgetAGIALPHA'],'cap_ok':cap_ok,'reviewers_required':tier['reviewersRequired'],'challenge_window_hours':tier['challengeWindowHours'],'settlement_split':{k:round(total*v,4) for k,v in split.items()},'claim_boundary':CLAIM_BOUNDARY}
    alpha = {'mission_id':mission['mission_id'],'alpha_wu':alpha_wu,'formula':'100*difficulty*quality*SLO*confidence*policy_pass','inputs':{'difficulty':difficulty,'quality':base_quality,'slo':slo,'confidence':confidence,'policy_pass':policy_pass},'claim_boundary':CLAIM_BOUNDARY}
    ready = {'mission_id':mission['mission_id'],'status':status,'missing_or_blocking_items':missing,'release_conditions':release_conditions,'mainnet_broadcast_allowed':False,'human_approval_required':tier.get('humanApprovalRequired',False),'claim_boundary':CLAIM_BOUNDARY}
    treasury = {'mission_id':mission['mission_id'],'treasury_allocation_agialpha':quote['settlement_split']['treasury'],'recommended_reinvestment':{'reviewer_capacity':0.35,'evidence_tooling':0.25,'compute_or_runtime':0.20,'capability_library':0.15,'reserve':0.05},'thermostat_notes':['If dispute rate rises, increase quorum and challenge window.','If validator latency rises, raise reviewer share.','If alpha-WU per AGIALPHA improves, allow larger mission budgets.'],'claim_boundary':CLAIM_BOUNDARY}
    proofbundle = {'mission_id':mission['mission_id'],'job_spec_hash':sha256_text(json.dumps(mission.get('goal',{}), sort_keys=True)),'policy_hash':sha256_text(json.dumps(policy, sort_keys=True)),'proof_requirements':proof,'artifact_status':'draft','replay_status':'pending','claim_boundary':CLAIM_BOUNDARY}
    return quote, alpha, ready, treasury, proofbundle

def run_all(args):
    mission = load_json(args.mission); policy = load_json(args.policy); out = pathlib.Path(args.out); mode=args.mode
    quote, alpha, ready, treasury, proofbundle = compute(mission, policy, mode)
    now = datetime.datetime.utcnow().replace(microsecond=0).isoformat()+'Z'
    write(out/'budget-quote.json', quote)
    write(out/'alpha-wu-score.json', alpha)
    write(out/'settlement-readiness.json', ready)
    write(out/'treasury-routing.json', treasury)
    write(out/'proofbundle.json', proofbundle)
    write(out/'funding-instructions.md', f"# Funding Instructions\n\nMission: {mission['title']}\n\nMode: {mode}\n\nTotal budget: {quote['total_budget_agialpha']} AGIALPHA\n\nThis is not a transaction. It is an operator instruction packet.\n\n{CLAIM_BOUNDARY}\n")
    write(out/'reviewer-packet.md', f"# Reviewer Packet\n\nMission: {mission['title']}\n\nObjective: {mission.get('goal',{}).get('objective','')}\n\nReview the ProofBundle, Evidence Docket, safety ledger, rollback plan, and release conditions.\n\nDecision: accept / reject / request changes.\n\n{CLAIM_BOUNDARY}\n")
    write(out/'evidence-docket.md', f"# Evidence Docket\n\nMission: {mission['title']}\n\nGenerated: {now}\n\n## Claim\nThis mission generated a public-safe proof-settlement readiness packet.\n\n## Status\n{ready['status']}\n\n## Alpha-WU\n{alpha['alpha_wu']}\n\n## Claim Boundary\n{CLAIM_BOUNDARY}\n")
    write(out/'chronicle-entry.md', f"# Chronicle Entry\n\nMission: {mission['mission_id']}\n\nStatus: {ready['status']}\n\nNext action: send reviewer-packet.md to reviewer and do not settle until all release conditions are supported.\n")
    page = f"""<!doctype html><html><head><meta charset='utf-8'><title>{html.escape(mission['title'])}</title><style>body{{font-family:system-ui;margin:40px;max-width:900px}}.card{{border:1px solid #ddd;border-radius:12px;padding:16px;margin:12px 0}}code{{background:#f3f4f6;padding:2px 4px}}</style></head><body><h1>{html.escape(mission['title'])}</h1><div class='card'><b>Status:</b> {ready['status']}<br><b>Total AGIALPHA budget:</b> {quote['total_budget_agialpha']}<br><b>alpha-WU:</b> {alpha['alpha_wu']}</div><div class='card'><h2>Files</h2><ul><li>budget-quote.json</li><li>proofbundle.json</li><li>evidence-docket.md</li><li>reviewer-packet.md</li><li>settlement-readiness.json</li><li>treasury-routing.json</li></ul></div><p><b>Claim boundary:</b> {CLAIM_BOUNDARY}</p></body></html>"""
    write(out/'index.html', page)
    print(f'AGIALPHA Autopilot generated evidence in {out}')
    print(f"Status: {ready['status']}")

if __name__ == '__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--mission', required=True)
    p.add_argument('--policy', required=True)
    p.add_argument('--out', required=True)
    p.add_argument('--mode', default='simulation', choices=['simulation','sepolia','mainnet_readonly'])
    args=p.parse_args(); run_all(args)
