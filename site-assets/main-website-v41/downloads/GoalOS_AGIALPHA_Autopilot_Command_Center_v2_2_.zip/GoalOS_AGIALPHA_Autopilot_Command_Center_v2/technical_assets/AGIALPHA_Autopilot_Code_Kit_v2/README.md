# AGIALPHA Autopilot Code Kit v2

Copy this folder into the repository root. Run the simulation command in `docs/AGIALPHA_AUTOPILOT_START_HERE.md`. This kit does not move tokens or broadcast Mainnet transactions.
